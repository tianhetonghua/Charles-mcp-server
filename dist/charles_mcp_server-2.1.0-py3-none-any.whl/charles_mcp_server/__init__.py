# charles_mcp_server/__init__.py

__version__ = "2.1.0"
__author__ = "7owe2"


from .main import mcp